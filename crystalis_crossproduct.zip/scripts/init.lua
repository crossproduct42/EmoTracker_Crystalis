Tracker:AddItems("items/common.json")

if (Tracker.ActiveVariantUID == "items_only") then
	Tracker:AddLayouts("layouts/tracker.json")

	else if (Tracker.ActiveVariantUID == "items_and_locations") then
		Tracker:AddLayouts("layouts/location_tracker.json")

	else
		Tracker:AddLayouts("layouts/map_tracker.json")
		Tracker:AddMaps("maps/maps.json")
		Tracker:AddLocations("locations/worn_locations.json")
		Tracker:AddLocations("locations/bonus_locations.json")
		Tracker:AddLocations("locations/weapon_locations.json")
		Tracker:AddLocations("locations/key_locations.json")
		Tracker:AddLocations("locations/magic_locations.json")
	end

end

Tracker:AddLayouts("layouts/broadcast.json")
